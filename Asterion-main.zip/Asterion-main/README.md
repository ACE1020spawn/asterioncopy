# Welcome to planet Asterion
Hello! Welcome to Asterion!
This is collaboration mod.

# Links
[![Discord](https://img.shields.io/discord/1278276676811358238?style=for-the-badge&color=ff9199&logo=discord&label=Asterion%20Server)](https://discord.gg/PcTnJ96mwf)
